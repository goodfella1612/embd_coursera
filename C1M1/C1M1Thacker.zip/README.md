Used to calculate diffrent statistics such as average median etc
@author Dev Thacker
@date May 20 2025
